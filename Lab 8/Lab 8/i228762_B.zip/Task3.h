#pragma once
#include <iostream>
#include <string>
#include "task1.h"

using namespace std;

// to implement a stack using multiple queues.
class Stack
{
private:
	Queue<int> q1, q2;
public:
	Stack() {
		q1 = Queue<int>();
		q2 = Queue<int>();
	}
	void push(int x) {
		if (q1.isEmpty())
			q2.enqueue(x);
		else
			q1.enqueue(x);
	}
	int pop() {
		int x;
		if (q1.isEmpty()) {
			while (!q2.isEmpty()) {
				x = q2.show_front();
				if (!q2.isEmpty())
					q1.enqueue(x);
			}
			return x;
		}
		else {
			while (!q1.isEmpty()) {
				x = q1.show_front();
				if (!q1.isEmpty())
					q2.enqueue(x);
			}
			return x;
		}
	}
	int top() {
		int x;
		if (q1.isEmpty()) {
			while (!q2.isEmpty()) {
				x = q2.show_front();
				q1.enqueue(x);
			}
			return x;
		}
		else {
			while (!q1.isEmpty()) {
				x = q1.show_front();
				q2.enqueue(x);
			}
			return x;
		}
	}
	bool isEmpty() {
		return q1.isEmpty() && q2.isEmpty();
	}
	void display() {
		if (q1.isEmpty()) {
			while (!q2.isEmpty()) {
				cout << q2.show_front() << " ";
			}
		}
		else {
			while (!q1.isEmpty()) {
				cout << q1.show_front() << " ";
			}
		}
		cout << endl;
	}
};
