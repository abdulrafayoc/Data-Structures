#include <iostream>
#include "task2.h"
#include "task3.h"
#include "task4.h"

using namespace std;

int main() {


	string s;

cin >> s;
//heavy_$$$_encriptoooooooor(s);
robin_bhai();
	
}