#include <iostream>
#include <fstream>
#include <string>
#include "Task 1.h"
#include "Task 3.h"
using namespace std;

int main() {

	fstream file;
	file.open("file.csv");

	Stack<Student> students;
	
	string line;
	getline(file, line);
	for (int i = 0; i < 30; i++) {
		if (file.eof()) {
			break;
		}
		getline(file, line);
		Student temp;
		temp.set_student(line);
		students.push(temp);
	}

	students.peak().display();

	return 0;

}